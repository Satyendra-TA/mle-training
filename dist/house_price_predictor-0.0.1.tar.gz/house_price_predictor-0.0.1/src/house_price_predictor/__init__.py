from .logging_utils import setup_logging

setup_logging()
